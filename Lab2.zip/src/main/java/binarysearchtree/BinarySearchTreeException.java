// Eduardo Ariza Abad y Enrique Ibáñez Rico

package binarysearchtree;

public class BinarySearchTreeException extends RuntimeException {
    public BinarySearchTreeException(String message) {
        super(message);
    }
}
